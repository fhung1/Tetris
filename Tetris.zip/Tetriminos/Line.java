public class Line extends Tetrimino{
  private int[][] squaresTemp = {{19, 3}, {19, 4}, {19, 5}, {19, 6}};
  private int[] URBoundTemp = {21, 6};
  private int[] BLBoundTemp = {18, 3};
  
  public Line(){
    squares = squaresTemp;
    URBound = URBoundTemp;
    BLBound = BLBoundTemp;
    hex = "#00FFFF";
  }  
}