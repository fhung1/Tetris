class Squiggly extends Tetrimino{
  private int[][] squaresTemp = {{19, 4}, {19, 5}, {18, 3}, {18, 4}};
  private int[] URBoundTemp = {20, 5};
  private int[] BLBoundTemp = {18, 3};
  public Squiggly(){
    squares = squaresTemp;
    URBound = URBoundTemp;
    BLBound = BLBoundTemp;
    hex = "#00FF00";   
  }  
}