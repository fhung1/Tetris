class ReverseSquiggly extends Tetrimino{
  private int[][] squaresTemp = {{19, 3}, {19, 4}, {18, 4}, {18, 5}};
  private int[] URBoundTemp = {20, 5};
  private int[] BLBoundTemp = {18, 3};
   public ReverseSquiggly(){
    squares = squaresTemp;
    URBound = URBoundTemp;
    BLBound = BLBoundTemp;
    hex = "#FF0000";
  }  

}