public class T extends Tetrimino{
  private int[][] squaresTemp = {{19, 3}, {19, 4}, {19, 5}, {18, 4}};
  private int[] URBoundTemp = {20, 5};
  private int[] BLBoundTemp = {18, 3};
  public T(){   
    squares = squaresTemp;
    URBound = URBoundTemp;
    BLBound = BLBoundTemp;
    hex = "#00FFFF";
  }
}