class LPiece extends Tetrimino{
  private int[][] squaresTemp = {{19, 3}, {19, 4}, {19, 5}, {18, 3}};
  private int[] URBoundTemp = {20, 5};
  private int[] BLBoundTemp = {18, 3};
  public LPiece(){
    squares = squaresTemp;
    URBound = URBoundTemp;
    BLBound = BLBoundTemp;
    hex = "#FFA500";
  } 

}