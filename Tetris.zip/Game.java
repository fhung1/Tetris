import java.util.*;
public class Game{
  private ArrayList<Tetrimino> next = new ArrayList<Tetrimino>();
  private Tetrimino current; //public or static?
  public static boolean[][] board = new boolean[20][10];

  public Game(){
    
  }

  private void runTime(){
    while(true) {
    for(int i = 0; i < 2147483647 ; i++) {
        for(int j = 0; j < 2147483647 ; j++){
        }
      runTick();
      }
    }
  }
  
  private void runTick(){
    if(!current.moveDownIfCan()){
        current = next.remove(0);
        next.add(instantiateRandom());
      }
  }

  private boolean moveDownIfCan(){
    for(int[] coords: current.getLowSquares())
      if(coords[0] == 0 || board[coords[0]-1][coords[1]])
        return false;
    current.moveDown();
    return true;
  }

  private Tetrimino instantiateRandom(){
    
  }
}